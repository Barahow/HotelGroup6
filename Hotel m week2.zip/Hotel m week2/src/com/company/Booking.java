package com.company;

import java.util.Date;

public class Booking {
    private Date BookingId;
    private Date checkInDate;
    private double totalPrice;


}
