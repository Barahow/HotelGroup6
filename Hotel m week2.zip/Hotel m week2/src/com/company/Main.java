package com.company;

import java.awt.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Main myapp = new Main();


        Scanner input = new Scanner(System.in);

        int choice = 0;

        while (choice== 0) {
            myapp.Printmenu();
            System.out.println("enter your choice?");
            choice = input.nextInt();
        }
        if (choice == 1) {
            myapp.printRooms();

        } else if (choice== 2) {
            myapp.printCustomer();
        }
        if (choice==0) {
            System.exit(0);
        }

    }
       private void printRooms() {
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to our hotel");

        Hotellogic kingsHouse = new Hotellogic();



        System.out.println("Do you want to book a room?");
        String answer = input.nextLine();



        if (answer.equalsIgnoreCase("yes")) {


            System.out.println("We have " + kingsHouse.getEmptyRooms() + " empty rooms.");
            for (int i = 0; i < kingsHouse.getRooms().size(); i++) {
                Room room = ((Room) kingsHouse.getRooms().get(i));
                if (!room.getBooked()) {
                    System.out.println("Room number: " + room.getRoomNumber()
                            + "\nBeds: " + room.getBeds()
                            + "\nSize: " + room.getSize()
                            + "\nBooked: " + room.getBooked());
                }
            }
            System.out.println("Which room do you want?");
            int roomNumber = input.nextInt();
            kingsHouse.bookRoom(roomNumber);
            System.out.println("Your room is booked!");




            }



        }



    private void Printmenu() {
        System.out.println("-----Welcome to hotel management----");
        System.out.println("(1)----Book Room---------");
        System.out.println("(2)----Add Customer-------");
        System.out.println("(0)------Exit--------");



    }
    private void printCustomer() {
        Scanner input = new Scanner(System.in);
        System.out.println("welcome!");
        Customer addCustomer = new Customer();
        System.out.println("Whats your name");
        addCustomer.getName(input.nextLine());
        System.out.println("whats your ssn?");
        addCustomer.getSsn(input.nextLine());
        System.out.println("whats your adress?");
        addCustomer.getAddress(input.nextLine());










    }
}














/*        kingsHouse.bookRoom(1);
        kingsHouse.bookRoom(2);
        kingsHouse.unBookRoom(2);
        kingsHouse.getBookedRooms();
        System.out.println("These are all rooms: " + kingsHouse.getRooms().size());
        for (int i = 0; i < kingsHouse.getRooms().size(); i++) {
            Room room = ((Room) kingsHouse.getRooms().get(i));
            System.out.println("Room number: " + room.getRoomNumber()
                    + "\nBeds: " + room.getBeds()
                    + "\nSize: " + room.getSize()
                    + "\nBooked: " + room.getBooked());
        }
        System.out.println("Number of rooms booked: \n"+ kingsHouse.getBookedRooms() );*/

