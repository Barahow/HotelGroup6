package com.company;

public class Customer {

    private String ssn;
    private String name;

    public String getSsn(String s) {
        return ssn;
    }

    private String address;

    public String getName(String s) {
        return name;
    }

    public String getAddress(String s) {
        return address;
    }

    private String telephoneNumber;



    }



