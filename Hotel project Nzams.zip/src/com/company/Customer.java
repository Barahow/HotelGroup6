package com.company;

public class Customer {
    private String name;
    private String ID;
    private  String phoneNr;

    public Customer(String name, String ID, String phoneNr) {
        this.name = name;
        this.ID = ID;
        this.phoneNr = phoneNr;
    }

    public String getName() {
        return name;

    }

    public void setName(String name) {
        this.name = name;
    }

    public String getID() {
        return ID;
    }

    public void setID() {
        this.ID = ID;
    }

    public String getphoneNr() {
        return phoneNr;
    }

    public void setphoneNr() {
        this.phoneNr = phoneNr;

    }

}


