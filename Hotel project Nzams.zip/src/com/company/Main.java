package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

        public class Main {
            ArrayList<Customer> customers = new ArrayList<>();
            ArrayList<Room> rooms = new ArrayList<>();

            public static void Main(String[] args) {
                Main main = new Main();
                boolean exit = false;
                while (!exit){
                    exit = main.menu();
                }
            }
            private boolean menu(){
                boolean exit = false;
                System.out.println("Choose a number what you want to do");
                System.out.println("1 view all customers");
                System.out.println("2 view all rooms");
                System.out.println("3 view Available rooms");
                System.out.println("5 Add a room");
                System.out.println("6 Edit a room");
                System.out.println("7 Add new customer");
                System.out.println("8 Remove a customer");
                System.out.println("9 Search for a booking");
                System.out.println("10 Exit");
                int n = getInt();
                System.out.println("-------------------------------------");
                switch (n){
                    case 1: listCustomers();
                        break;
                    case 2: listRooms();
                        break;
                    case 3: listAvailableRooms();
                        break;
                    case 4: addRoom();
                        break;
                    case 5: editRoom();
                        break;
                    case 6: removeRoom();
                        break;
                    case 7: addCustomer();
                        break;
                    case 8: removeCustomer();
                        break;
                    case 9:
                        System.out.println("Not implemented");
                        break;
                    case 10: exit = true;
                        System.out.println("customers saved");
                        writeToFile();
                        break;
                    default:
                        System.out.println("!!! Incorrect input!!!");
                        System.out.println("---------------------------------------------");



                }

                return exit;
            }

            private void listCustomers() {
                System.out.println("List of all customers");
                for (int i =0; i < customers.size(); i++) {
                    Customer customer = customers.get(i);
                    System.out.println(i+1 + " : Name:" + customer.getName() +
                            " ID:" + customer.getID() + "phone number: " + customer.getphoneNr());
                }
                System.out.println("------------------------------------------------------");
            }
            private void listRooms() {
                System.out.println("List of all rooms");
                for (int i = 0; i < rooms.size(); i++) {
                    System.out.println(i + 1 + " Room number" + rooms.get(i).getNumber()
                            + " Available " + rooms.get(i).isAvailable());
                }


                System.out.println("-------------------------------------------");
            }
                private void listAvailableRooms(){
                    System.out.println("Available rooms");
                    for (int i = 0; i< rooms.size(); i++) {
                        if (rooms.get(i).isAvailable()) {
                        System.out.println(i+1 + ": Room number" + rooms.get(i).getNumber()
                                + "Available:" + rooms.get(i).isAvailable());
                    }
                }
                System.out.println("-----------------------------------------------------------------");
            }
            private void addRoom(){
                System.out.println("Add new room");
                System.out.println("Enter room number");
                int n = getInt();

                Room room = new Room(n,  true);
                        rooms.add (room);
                }
                private void removeRoom() {

                    System.out.println("Remove a room");
                    listRooms();
                    System.out.println("choose number to remove the room");
                    int index = getInt()-1;
                    if (index > rooms.size() || index < 0){
                        System.out.println("!!!!!! Incorrect index !!!!!!! - No change made");
                    }else {
                        System.out.println("Room removed");
                        System.out.println("----------------------------------------------------------");
                        rooms.remove(index);
                    }

                }
                    private void editRoom(){
                        listRooms();
                        System.out.println("choose which room to edit (enter number)");
                        int n = getInt() -1;
                        if (n>rooms.size() || n < 0) {
                            System.out.println("Incorrect index");
                        }else {
                            System.out.println("Type Y for available or N for unavailable or X to cancel");
                            String s = getString();

                            Room room = rooms.get(n);

                            switch (s){
                                case "Y": room.setAvailable(true);
                                    System.out.println("Room status changed to AVAILABLE");
                                    break;
                                case "N": room.setAvailable(false);
                                    System.out.println("Room status changed to UNAVAILABLE");

                                    break;
                                case "X":
                                    break;

                                default:
                                    System.out.println("!!!! Wrong input !!!! - No change made");
                            }
                            System.out.println("----------------------------------------------------");
                        }
                    }
                    private void addCustomer(){
                        System.out.println("Add new customer");
                        System.out.println("Enter customer Name");
                        String name = getString();
                        System.out.println("Enter customer ID:");
                        String ID = getString();
                        System.out.println("Enter customer phone number:");
                        String phoneNumber = getString();

                        Customer customer = new Customer (name,ID, phoneNumber);
                        customers.add(customer);
                    }
                    private void removeCustomer() {
                    System.out.println("Remove a customer");
                    listCustomers();
                    System.out.println("Enter number to remove the customer");
                    int index = getInt() - 1;
                    if (index > rooms.size() || index < 0) {
                        System.out.println("!!!! incorrect index !!!! - No change made");
                    } else {
                        System.out.println("customer removed");
                        System.out.println("---------------------------------------------------------------");
                        customers.remove(index);
                    }

                }
                    private int getInt() {
                        Scanner scanner = new Scanner(System.in);
                int n = scanner.nextInt();
                return n;
            }
            private String getString(){
                Scanner scanner = new Scanner (System.in);
                String s = scanner.nextLine();
                return s;
            }
            private void writeToFile(){
                try (FileWriter fw = new FileWriter (" customer.txt", false);
                BufferedWriter bw = new BufferedWriter(fw);
                PrintWriter out = new PrintWriter(bw)){

                    for (Customer customer: customers) {
                        out.println("Name:" + customer.getName() +
                                "ID:" + customer.getID() + "phone number:" +customer.getphoneNr());
                    }

                }catch (IOException e ){
                    e.printStackTrace();
                }
            }

        }






